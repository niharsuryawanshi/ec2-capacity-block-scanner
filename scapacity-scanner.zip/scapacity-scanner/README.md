# EC2 Capacity Block Scanner

A Streamlit web application for scanning AWS EC2 Capacity Block availability across multiple regions. The application provides real-time capacity scanning with parallel processing and an intuitive interface for exploring availability patterns.

## Features

### Multi-Region Scanner
- **Simultaneous region scanning**: Check capacity across all AWS regions at once
- **Parallel processing**: Configurable concurrency (1-20 regions simultaneously)
- **Real-time progress**: Live updates with detailed status logging
- **Smart sorting**: Results automatically sorted by price
- **Retry logic**: Built-in exponential backoff for API resilience

### Grid View Scanner  
- **Visual date matrix**: 7x7 grid showing start date vs end date combinations
- **Interactive navigation**: Arrow controls to explore different date ranges
- **Single region focus**: Deep dive into specific region availability
- **Parallel cell checking**: Configurable concurrency for grid cells
- **Price visualization**: See capacity availability and pricing in grid format

### Core Capabilities
- **Parameter synchronization**: Settings automatically sync between views
- **Flexible configuration**: Customizable instance types, quantities, and durations
- **Performance controls**: Adjustable concurrency for optimal API usage
- **Clean architecture**: Modular design with separated concerns

## Quick Start

### Prerequisites
- Python 3.8 or higher
- AWS credentials configured (via AWS CLI, environment variables, or IAM roles)
- Required Python packages (see `requirements.txt`)

### Installation

```bash
# Clone or navigate to the project directory
cd capacity_block

# Create and activate virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the application
streamlit run main.py
```

### Access the Application
- **Local URL**: http://localhost:8501
- **Network URL**: http://[your-ip]:8501

## Usage Guide

### Multi-Region Scanner

1. **Set Parameters**:
   - **Instance Type**: e.g., `m5.large`, `c5.xlarge`
   - **Primary Region**: Starting region for the search
   - **Instance Count**: Number of instances (1-100)
   - **Earliest Start Date**: When capacity should begin
   - **Duration**: Capacity block duration in days (1, 3, 7, 14, 30, 60, 90)

2. **Performance Settings**:
   - **Max Concurrent Regions**: Number of regions to check simultaneously (1-20)
   - Higher values = faster scanning but more API calls

3. **Run Scan**:
   - Click "Scan All Regions" to start
   - Monitor real-time progress and logs
   - Results show availability, pricing, and availability zones

### Grid View Scanner

1. **Set Parameters**:
   - **Instance Type**: Target instance type
   - **Target Region**: Single region to focus on
   - **Instance Count**: Number of instances needed
   - **Base Date**: Starting date for the grid

2. **Navigate the Grid**:
   - **▲/▼**: Move start dates up/down 7 days
   - **◀/▶**: Move end dates left/right 7 days
   - Each cell shows a start date + end date combination

3. **Performance Settings**:
   - **Max Concurrent Cells**: Cells to check simultaneously (1-49)
   - Adjust based on your API rate limits

4. **Interpret Results**:
   - **Green cells**: Capacity available with pricing
   - **Red cells**: No capacity available
   - **Gray cells**: Invalid date combinations

## Configuration

### AWS Credentials

Configure AWS access using any of these methods:

**AWS CLI** (Recommended):
```bash
aws configure
```

**Environment Variables**:
```bash
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_DEFAULT_REGION=us-east-1
```

**IAM Roles** (for EC2 instances):
Attach an IAM role with EC2 describe permissions to your instance.

### Required AWS Permissions

Your AWS credentials need these permissions:
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ec2:DescribeCapacityBlockOfferings",
                "ec2:DescribeRegions",
                "ec2:DescribeAvailabilityZones"
            ],
            "Resource": "*"
        }
    ]
}
```

### Application Settings

The application uses these default values (configurable via UI):

- **Default Instance Type**: `m5.large`
- **Default Region**: `us-east-1`
- **Default Quantity**: `1`
- **Default Duration**: `1 day`
- **Max Workers (Multi-Region)**: `10` (limit: 20)
- **Max Workers (Grid)**: `25` (limit: 49)

## Project Structure

```
capacity_block/
├── main.py                 # Application entry point
├── requirements.txt        # Python dependencies
├── config/
│   ├── __init__.py
│   └── constants.py        # Application constants and defaults
├── core/
│   ├── __init__.py
│   └── capacity_checker.py # Core capacity checking logic
├── ui/
│   ├── __init__.py
│   ├── components.py       # Reusable UI components
│   └── pages.py           # Page-specific logic
├── utils/
│   ├── __init__.py
│   ├── aws_helpers.py     # AWS API utilities
│   ├── date_helpers.py    # Date manipulation utilities
│   └── formatters.py      # Data formatting utilities
└── static/
    └── styles.css         # Custom CSS styling
```

## Architecture

### Modular Design
- **UI Layer** (`ui/`): Streamlit components and page logic
- **Core Logic** (`core/`): Capacity checking algorithms and AWS interactions
- **Utilities** (`utils/`): Helper functions for AWS, dates, and formatting
- **Configuration** (`config/`): Constants and default values

### Parallel Processing
- **ThreadPoolExecutor**: Concurrent API calls for better performance
- **Retry Logic**: Exponential backoff for API rate limiting
- **Progress Tracking**: Real-time updates during long operations

### State Management
- **Streamlit Session State**: Persistent UI state across interactions
- **Parameter Synchronization**: Automatic syncing between scanner modes
- **Navigation State**: Grid position tracking for seamless exploration

## Troubleshooting

### Common Issues

**AWS Credentials Not Found**:
```
NoCredentialsError: Unable to locate credentials
```
Solution: Configure AWS credentials using `aws configure` or environment variables.

**API Rate Limiting**:
```
Throttling: Rate exceeded
```
Solution: Reduce concurrency settings or wait before retrying.

**Region Access Denied**:
```
UnauthorizedOperation: You are not authorized to perform this operation
```
Solution: Ensure your AWS credentials have the required EC2 permissions.

**Import Errors**:
```
ModuleNotFoundError: No module named 'streamlit'
```
Solution: Install dependencies with `pip install -r requirements.txt`.

### Performance Tips

1. **Optimize Concurrency**: Start with lower values and increase gradually
2. **Monitor API Usage**: AWS has rate limits for EC2 APIs
3. **Use Appropriate Instance**: Better hardware = faster processing
4. **Filter Regions**: Focus on regions where you actually need capacity

### Getting Help

1. **Check Logs**: Application shows detailed error messages
2. **Verify Credentials**: Test with `aws sts get-caller-identity`
3. **Test API Access**: Try a simple EC2 describe operation
4. **Review Permissions**: Ensure your IAM policy includes required actions

## Development

### Running in Development Mode

```bash
# Install development dependencies
pip install -r requirements.txt

# Run with debug output
streamlit run main.py --logger.level=debug

# Run with custom port
streamlit run main.py --server.port=8502
```

### Code Style
- **Functions**: Clear, single-purpose functions
- **Error Handling**: Comprehensive try-catch blocks
- **Documentation**: Docstrings for all major functions
- **Type Hints**: Used throughout for better code clarity

### Testing Locally

```bash
# Test AWS connectivity
python -c "import boto3; print(boto3.client('sts').get_caller_identity())"

# Test EC2 API access
python -c "
import boto3
ec2 = boto3.client('ec2', region_name='us-east-1')
print('Regions:', len(ec2.describe_regions()['Regions']))
"

# Test capacity block API
python -c "
import boto3
from datetime import datetime, timedelta
ec2 = boto3.client('ec2', region_name='us-east-1')
start = datetime.now() + timedelta(days=1)
end = start + timedelta(days=1)
offers = ec2.describe_capacity_block_offerings(
    InstanceType='m5.large',
    InstanceCount=1,
    StartDateRange=start,
    EndDateRange=end,
    CapacityDurationHours=24
)
print('API works, offers found:', len(offers['CapacityBlockOfferings']))
"
```

## Related Documentation

- **AWS Deployment**: See [DEPLOYMENT.md](DEPLOYMENT.md) for deployment instructions
- **Technical Issues**: See [NUMPY_PANDAS_FIX.md](NUMPY_PANDAS_FIX.md) for dependency troubleshooting

## License

This project is provided as-is for educational and operational use. Modify as needed for your specific requirements.
