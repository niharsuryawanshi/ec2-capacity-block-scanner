# Configuration and constants
