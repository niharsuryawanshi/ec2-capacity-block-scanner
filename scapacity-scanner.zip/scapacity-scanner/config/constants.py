"""
Application constants and configuration values
"""

# Allowed duration (days): 1–14, then weekly multiples up to 182
VALID_DURATIONS = list(range(1, 15)) + list(range(21, 183, 7))

# Default configuration values
DEFAULT_INSTANCE_TYPE = "trn1.32xlarge"
DEFAULT_REGION = "us-west-2"
DEFAULT_QUANTITY = 1
DEFAULT_DURATION_DAYS = 7
DEFAULT_CONCURRENCY = 10
DEFAULT_GRID_CONCURRENCY = 10

# Performance settings
MAX_WORKERS_LIMIT = 20
MAX_GRID_WORKERS_LIMIT = 25
API_RETRY_ATTEMPTS = 5
CACHE_TTL = 300  # seconds

# AWS API limits
MAX_RESULTS = 100
INSTANCE_COUNT_RANGE = (1, 64)

# Grid settings
GRID_SIZE = 7
