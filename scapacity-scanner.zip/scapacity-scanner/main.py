#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EC2 Capacity Blocks Scanner - Main Application
A modular Streamlit application for scanning AWS EC2 Capacity Block availability
"""
import streamlit as st

# Import modular components
from ui.components import (
    setup_page_config, load_css, create_sidebar_controls, 
    synchronize_page_parameters, display_empty_results
)
from ui.pages import run_multi_region_scan, run_grid_scan, display_grid_view


def main():
    """Main application entry point"""
    # Setup page configuration and load CSS
    setup_page_config()
    load_css()

    # Main content wrapper for proper alignment
    with st.container():
        # Page selection with consistent spacing
        page = st.selectbox("Select View", ["Multi-Region Scanner", "Grid View Scanner"], key="page_selector")

        # Initialize and handle page synchronization
        if "previous_page" not in st.session_state:
            st.session_state.previous_page = page

        # Check if page has changed and synchronize parameters
        synchronize_page_parameters(page, st.session_state.previous_page)
        st.session_state.previous_page = page

        # Create sidebar controls based on page type
        if page == "Multi-Region Scanner":
            controls = create_sidebar_controls("multi_region")
            
            # Main content area for multi-region scanner
            with st.container():
                if controls["run_scan"]:
                    run_multi_region_scan(controls)
                else:
                    display_empty_results("multi_region")
        
        elif page == "Grid View Scanner":
            controls = create_sidebar_controls("grid")
            
            # Main content area for grid scanner
            with st.container():
                if controls["run_scan"]:
                    run_grid_scan(controls)
                else:
                    display_grid_view(controls)
                    display_empty_results("grid")


if __name__ == "__main__":
    main()
