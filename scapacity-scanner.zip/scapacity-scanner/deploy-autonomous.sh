#!/bin/bash
set -e

# EC2 Capacity Block Scanner - Completely Autonomous Deployment
# This script packages the application, uploads to S3, and deploys via CloudFormation
# No user input required except AWS credentials and key pair

echo "🚀 EC2 Capacity Block Scanner - Fully Autonomous AWS Deployment"
echo "=============================================================="

# Check prerequisites
check_prerequisites() {
    echo "📋 Checking prerequisites..."
    
    # Check AWS CLI
    if ! command -v aws &> /dev/null; then
        echo "❌ AWS CLI not found. Please install AWS CLI first."
        echo "   Install: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html"
        exit 1
    fi
    
    # Check zip command
    if ! command -v zip &> /dev/null; then
        echo "❌ zip command not found. Please install zip utility."
        exit 1
    fi
    
    # Check AWS credentials
    if ! aws sts get-caller-identity &> /dev/null; then
        echo "❌ AWS credentials not configured. Please run 'aws configure'"
        exit 1
    fi
    
    # Check if required files exist
    if [[ ! -f "cloudformation-template-autonomous.yaml" ]]; then
        echo "❌ Autonomous CloudFormation template not found: cloudformation-template-autonomous.yaml"
        exit 1
    fi
    
    if [[ ! -f "main.py" ]]; then
        echo "❌ Main application file not found: main.py"
        exit 1
    fi
    
    if [[ ! -f "requirements.txt" ]]; then
        echo "❌ Requirements file not found: requirements.txt"
        exit 1
    fi
    
    echo "✅ Prerequisites check passed"
}

# Auto-generate unique identifiers
generate_deployment_config() {
    echo ""
    echo "🔧 Generating autonomous deployment configuration..."
    
    # Get AWS account ID and region
    AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
    AWS_REGION=$(aws configure get region 2>/dev/null || echo "us-west-2")
    
    # Generate unique identifiers
    TIMESTAMP=$(date +%Y%m%d-%H%M%S)
    DEPLOYMENT_ID="${AWS_ACCOUNT_ID}-${AWS_REGION}-${TIMESTAMP}"
    
    # Generate S3 bucket name (globally unique)
    S3_BUCKET_NAME="capacity-scanner-$(echo ${DEPLOYMENT_ID} | tr '[:upper:]' '[:lower:]')"
    
    # Generate stack name
    STACK_NAME="capacity-block-scanner-${TIMESTAMP}"
    
    # Generate application package name
    APPLICATION_PACKAGE_NAME="capacity-scanner-${TIMESTAMP}.zip"
    
    # Set project name
    PROJECT_NAME="capacity-block-scanner"
    
    echo "✅ Configuration generated:"
    echo "   AWS Account: ${AWS_ACCOUNT_ID}"
    echo "   AWS Region: ${AWS_REGION}"
    echo "   S3 Bucket: ${S3_BUCKET_NAME}"
    echo "   Stack Name: ${STACK_NAME}"
    echo "   Package: ${APPLICATION_PACKAGE_NAME}"
}

# Validate requirements.txt for compatibility
validate_requirements() {
    echo ""
    echo "🔍 Validating requirements.txt for numpy/pandas compatibility..."
    
    if [[ ! -f "requirements.txt" ]]; then
        echo "❌ requirements.txt not found"
        return 1
    fi
    
    # Check if numpy is pinned to compatible version
    if grep -q "numpy==1.24.3" requirements.txt; then
        echo "✅ numpy pinned to compatible version (1.24.3)"
    else
        echo "⚠️ numpy not pinned to tested version. Adding compatibility fix..."
        # Create backup and update requirements.txt
        cp requirements.txt requirements.txt.backup
        echo "# Compatibility fix applied by deploy script" >> requirements.txt
        echo "numpy==1.24.3" >> requirements.txt
    fi
    
    # Check if pandas is pinned to compatible version
    if grep -q "pandas==2.0.3" requirements.txt; then
        echo "✅ pandas pinned to compatible version (2.0.3)"
    else
        echo "⚠️ pandas not pinned to tested version"
    fi
    
    echo "✅ Requirements validation completed"
}

# Create application package
create_application_package() {
    echo ""
    echo "📦 Creating application package..."
    echo "Package name: $APPLICATION_PACKAGE_NAME"
    
    # Validate requirements first
    validate_requirements
    
    # Create temporary directory for packaging
    local temp_dir="/tmp/capacity-scanner-deploy-${TIMESTAMP}"
    rm -rf "$temp_dir"
    mkdir -p "$temp_dir"
    
    # Copy application files (excluding backup and myenv)
    echo "📋 Copying application files..."
    
    # Copy main files
    cp main.py "$temp_dir/"
    cp requirements.txt "$temp_dir/"
    
    # Copy directories if they exist
    for dir in ui core config utils static; do
        if [[ -d "$dir" ]]; then
            echo "  📁 Copying $dir/"
            cp -r "$dir" "$temp_dir/"
        fi
    done
    
    # Add deployment validation script
    echo "🔧 Adding deployment validation script..."
    cat > "$temp_dir/validate-deployment.py" << 'EOFVAL'
#!/usr/bin/env python3
"""
Deployment validation script for numpy/pandas compatibility
"""
import sys
import importlib.util

def validate_imports():
    """Validate critical imports work correctly"""
    print("🔍 Validating critical imports...")
    
    try:
        import numpy
        print(f"✅ numpy {numpy.__version__} imported successfully")
        
        # Test numpy basic functionality
        arr = numpy.array([1, 2, 3])
        print(f"✅ numpy array creation works: {arr}")
        
    except Exception as e:
        print(f"❌ numpy import/usage failed: {e}")
        return False
    
    try:
        import pandas
        print(f"✅ pandas {pandas.__version__} imported successfully")
        
        # Test pandas basic functionality
        df = pandas.DataFrame({'test': [1, 2, 3]})
        print(f"✅ pandas DataFrame creation works: {df.shape}")
        
    except Exception as e:
        print(f"❌ pandas import/usage failed: {e}")
        return False
    
    try:
        import streamlit
        print(f"✅ streamlit {streamlit.__version__} imported successfully")
        
    except Exception as e:
        print(f"❌ streamlit import failed: {e}")
        return False
    
    print("✅ All critical imports validated successfully")
    return True

if __name__ == "__main__":
    success = validate_imports()
    sys.exit(0 if success else 1)
EOFVAL
    
    chmod +x "$temp_dir/validate-deployment.py"
    
    # Create the zip package
    echo "🗜️  Creating zip package..."
    cd "$temp_dir"
    zip -r "/tmp/$APPLICATION_PACKAGE_NAME" . -x "*.pyc" "*/__pycache__/*" "*.DS_Store"
    cd - > /dev/null
    
    # Verify package contents
    echo "📋 Package contents:"
    unzip -l "/tmp/$APPLICATION_PACKAGE_NAME"
    
    # Clean up temp directory
    rm -rf "$temp_dir"
    
    APPLICATION_PACKAGE_PATH="/tmp/$APPLICATION_PACKAGE_NAME"
    echo "✅ Application package created: $APPLICATION_PACKAGE_PATH"
}

# Create S3 bucket and upload application
upload_to_s3() {
    echo ""
    echo "☁️  Creating S3 bucket and uploading application..."
    echo "Bucket: s3://$S3_BUCKET_NAME"
    
    # Create S3 bucket
    echo "🪣 Creating S3 bucket: $S3_BUCKET_NAME"
    if [[ "$AWS_REGION" == "us-east-1" ]]; then
        aws s3api create-bucket --bucket "$S3_BUCKET_NAME" --region "$AWS_REGION"
    else
        aws s3api create-bucket --bucket "$S3_BUCKET_NAME" --region "$AWS_REGION" \
            --create-bucket-configuration LocationConstraint="$AWS_REGION"
    fi
    
    # Enable versioning
    aws s3api put-bucket-versioning --bucket "$S3_BUCKET_NAME" \
        --versioning-configuration Status=Enabled
    
    echo "✅ S3 bucket created and versioning enabled"
    
    # Upload application package
    echo "📤 Uploading application package..."
    S3_APPLICATION_KEY="applications/$APPLICATION_PACKAGE_NAME"
    aws s3 cp "$APPLICATION_PACKAGE_PATH" "s3://$S3_BUCKET_NAME/$S3_APPLICATION_KEY" --region "$AWS_REGION"
    
    if [[ $? -eq 0 ]]; then
        echo "✅ Application uploaded successfully"
        echo "S3 Location: s3://$S3_BUCKET_NAME/$S3_APPLICATION_KEY"
    else
        echo "❌ Failed to upload application to S3"
        exit 1
    fi
}

# Get VPC configuration (existing or new)
get_vpc_configuration() {
    echo ""
    echo "🌐 VPC Configuration"
    echo "==================="
    echo "Choose VPC configuration:"
    echo "1) Create new VPC (recommended for autonomous deployment)"
    echo "2) Use existing VPC"
    read -p "Enter choice (1 or 2): " vpc_choice
    
    case $vpc_choice in
        1)
            USE_EXISTING_VPC="false"
            echo "✅ Will create new VPC automatically"
            ;;
        2)
            USE_EXISTING_VPC="true"
            select_existing_vpc
            ;;
        *)
            echo "❌ Invalid choice. Using default: create new VPC"
            USE_EXISTING_VPC="false"
            ;;
    esac
}

# List and select existing VPC
select_existing_vpc() {
    echo ""
    echo "🌐 Available VPCs in $AWS_REGION:"
    
    # Get VPCs with names
    local vpc_info=$(aws ec2 describe-vpcs --region "$AWS_REGION" \
        --query 'Vpcs[*].[VpcId,CidrBlock,Tags[?Key==`Name`]|[0].Value||`(unnamed)`]' \
        --output table 2>/dev/null)
    
    if [[ $? -ne 0 ]] || [[ -z "$vpc_info" ]]; then
        echo "❌ Unable to list VPCs. Please check your permissions."
        echo "   Falling back to create new VPC"
        USE_EXISTING_VPC="false"
        return
    fi
    
    echo "$vpc_info"
    echo ""
    read -p "Enter VPC ID to use: " EXISTING_VPC_ID
    
    # Validate VPC exists
    if ! aws ec2 describe-vpcs --region "$AWS_REGION" --vpc-ids "$EXISTING_VPC_ID" &>/dev/null; then
        echo "❌ VPC $EXISTING_VPC_ID not found or not accessible"
        echo "   Falling back to create new VPC"
        USE_EXISTING_VPC="false"
        return
    fi
    
    echo "✅ Using existing VPC: $EXISTING_VPC_ID"
    select_existing_subnet
}

# List and select existing subnet
select_existing_subnet() {
    echo ""
    echo "🔗 Available Subnets in VPC $EXISTING_VPC_ID:"
    
    local subnet_info=$(aws ec2 describe-subnets --region "$AWS_REGION" \
        --filters "Name=vpc-id,Values=$EXISTING_VPC_ID" \
        --query 'Subnets[*].[SubnetId,CidrBlock,AvailabilityZone,Tags[?Key==`Name`]|[0].Value||`(unnamed)`,MapPublicIpOnLaunch]' \
        --output table 2>/dev/null)
    
    if [[ $? -ne 0 ]] || [[ -z "$subnet_info" ]]; then
        echo "❌ Unable to list subnets for VPC $EXISTING_VPC_ID"
        echo "   Falling back to create new VPC"
        USE_EXISTING_VPC="false"
        return
    fi
    
    echo "$subnet_info"
    echo ""
    echo "💡 Choose a public subnet (MapPublicIpOnLaunch = True) for internet access"
    read -p "Enter Subnet ID to use: " EXISTING_SUBNET_ID
    
    # Validate subnet exists and belongs to VPC
    local subnet_vpc=$(aws ec2 describe-subnets --region "$AWS_REGION" --subnet-ids "$EXISTING_SUBNET_ID" \
        --query 'Subnets[0].VpcId' --output text 2>/dev/null)
    
    if [[ "$subnet_vpc" != "$EXISTING_VPC_ID" ]]; then
        echo "❌ Subnet $EXISTING_SUBNET_ID does not belong to VPC $EXISTING_VPC_ID"
        echo "   Falling back to create new VPC"
        USE_EXISTING_VPC="false"
        return
    fi
    
    echo "✅ Using existing subnet: $EXISTING_SUBNET_ID"
}

# Get instance type selection
get_instance_type() {
    echo ""
    echo "💻 Instance Type Selection"
    echo "========================="
    echo "Choose EC2 instance type:"
    echo "1) t2.micro (1 vCPU, 1 GB RAM) - Free tier eligible"
    echo "2) t3.small (2 vCPU, 2 GB RAM) - Light workloads"
    echo "3) t3.medium (2 vCPU, 4 GB RAM) - Recommended"
    echo "4) t3.large (2 vCPU, 8 GB RAM) - Heavy workloads"
    echo "5) t3.xlarge (4 vCPU, 16 GB RAM) - High performance"
    echo ""
    read -p "Enter choice (1-5) [default: 3 for t3.medium]: " instance_choice
    
    case $instance_choice in
        1)
            INSTANCE_TYPE="t2.micro"
            echo "✅ Selected: t2.micro (Free tier eligible)"
            ;;
        2)
            INSTANCE_TYPE="t3.small"
            echo "✅ Selected: t3.small"
            ;;
        3|"")
            INSTANCE_TYPE="t3.medium"
            echo "✅ Selected: t3.medium (Recommended)"
            ;;
        4)
            INSTANCE_TYPE="t3.large"
            echo "✅ Selected: t3.large"
            ;;
        5)
            INSTANCE_TYPE="t3.xlarge"
            echo "✅ Selected: t3.xlarge"
            ;;
        *)
            echo "❌ Invalid choice. Using default: t3.medium"
            INSTANCE_TYPE="t3.medium"
            ;;
    esac
}

# Get available key pairs and auto-select or prompt
get_key_pair() {
    echo ""
    echo "🔑 Configuring EC2 Key Pair..."
    
    # List available key pairs
    local key_pairs=$(aws ec2 describe-key-pairs --region "$AWS_REGION" --query 'KeyPairs[*].KeyName' --output text 2>/dev/null)
    
    if [[ -z "$key_pairs" ]]; then
        echo "❌ No EC2 key pairs found in region $AWS_REGION"
        echo "   Please create a key pair first:"
        echo "   aws ec2 create-key-pair --key-name my-key --query 'KeyMaterial' --output text > my-key.pem"
        echo "   chmod 400 my-key.pem"
        exit 1
    fi
    
    # Count key pairs
    local key_count=$(echo "$key_pairs" | wc -w)
    
    if [[ $key_count -eq 1 ]]; then
        # Auto-select if only one key pair
        KEY_PAIR_NAME=$(echo "$key_pairs" | xargs)
        echo "✅ Auto-selected key pair: $KEY_PAIR_NAME"
    else
        # List available key pairs and prompt
        echo "🔑 Available EC2 Key Pairs in $AWS_REGION:"
        echo "$key_pairs" | tr ' ' '\n' | nl
        echo ""
        echo "Multiple key pairs found. Please select one:"
        read -p "Enter key pair name: " KEY_PAIR_NAME
        
        # Validate key pair exists
        if ! echo "$key_pairs" | grep -q "$KEY_PAIR_NAME"; then
            echo "❌ Key pair '$KEY_PAIR_NAME' not found"
            exit 1
        fi
    fi
    
    echo "✅ Using key pair: $KEY_PAIR_NAME"
}

# Deploy CloudFormation stack
deploy_stack() {
    echo ""
    echo "🚀 Deploying CloudFormation stack..."
    echo "Stack Name: $STACK_NAME"
    
    # Build parameters based on VPC configuration
    PARAMETERS="InstanceType=$INSTANCE_TYPE KeyPairName=$KEY_PAIR_NAME ProjectName=$PROJECT_NAME S3BucketName=$S3_BUCKET_NAME S3ApplicationKey=$S3_APPLICATION_KEY"
    
    if [[ "$USE_EXISTING_VPC" == "true" ]]; then
        PARAMETERS="$PARAMETERS UseExistingVPC=true ExistingVPCId=$EXISTING_VPC_ID ExistingSubnetId=$EXISTING_SUBNET_ID"
    else
        PARAMETERS="$PARAMETERS UseExistingVPC=false"
    fi
    
    echo "🔧 Parameters: $PARAMETERS"
    
    # Deploy the stack with parameters
    aws cloudformation deploy \
        --template-file cloudformation-template-autonomous.yaml \
        --stack-name "$STACK_NAME" \
        --parameter-overrides $PARAMETERS \
        --capabilities CAPABILITY_NAMED_IAM \
        --region "$AWS_REGION" \
        --no-fail-on-empty-changeset
    
    if [[ $? -eq 0 ]]; then
        echo "✅ CloudFormation stack deployed successfully!"
    else
        echo "❌ CloudFormation deployment failed"
        exit 1
    fi
}

# Get stack outputs
get_outputs() {
    echo ""
    echo "📊 Getting deployment outputs..."
    
    # Get stack outputs
    OUTPUTS=$(aws cloudformation describe-stacks \
        --stack-name "$STACK_NAME" \
        --region "$AWS_REGION" \
        --query 'Stacks[0].Outputs' \
        --output json)
    
    APPLICATION_URL=$(echo "$OUTPUTS" | jq -r '.[] | select(.OutputKey=="ApplicationURL") | .OutputValue')
    SSH_COMMAND=$(echo "$OUTPUTS" | jq -r '.[] | select(.OutputKey=="SSHCommand") | .OutputValue')
    ELASTIC_IP=$(echo "$OUTPUTS" | jq -r '.[] | select(.OutputKey=="ElasticIP") | .OutputValue')
    
    echo ""
    echo "🎉 Autonomous Deployment Completed Successfully!"
    echo "============================================="
    echo ""
    echo "📍 Application URL: $APPLICATION_URL"
    echo "🔗 SSH Command: $SSH_COMMAND"
    echo "💾 S3 Bucket: s3://$S3_BUCKET_NAME"
    echo ""
    echo "⏳ The application may take 2-3 minutes to fully start up."
    echo "   The EC2 instance is automatically downloading and installing your application."
    echo ""
    
    # Save deployment info
    cat > deployment-info-autonomous.txt << EOF
EC2 Capacity Block Scanner - Autonomous Deployment Information
===========================================================

Deployment Date: $(date)
AWS Region: $AWS_REGION
Stack Name: $STACK_NAME
S3 Bucket: $S3_BUCKET_NAME
Application Package: $S3_APPLICATION_KEY

Access Information:
- Application URL: $APPLICATION_URL
- Elastic IP: $ELASTIC_IP  
- SSH Command: $SSH_COMMAND

Autonomous Features:
✅ Application automatically packaged and uploaded to S3
✅ Complete infrastructure created automatically
✅ Application automatically downloaded and installed on EC2
✅ Service automatically started and configured
✅ Health checks and monitoring enabled

To delete the deployment:
aws cloudformation delete-stack --stack-name $STACK_NAME --region $AWS_REGION
aws s3 rb s3://$S3_BUCKET_NAME --force
EOF
    
    echo "💾 Deployment information saved to: deployment-info-autonomous.txt"
}

# Test deployment
test_deployment() {
    echo ""
    echo "🧪 Testing deployment..."
    
    # Wait for the service to start
    echo "⏳ Waiting 60 seconds for application startup..."
    sleep 60
    
    # Test HTTP connectivity with retry
    local retry_count=0
    local max_retries=5
    
    while [[ $retry_count -lt $max_retries ]]; do
        if curl -s --connect-timeout 10 "$APPLICATION_URL" > /dev/null; then
            echo "✅ Application is responding at $APPLICATION_URL"
            echo "🎯 Deployment test successful!"
            return 0
        else
            retry_count=$((retry_count + 1))
            if [[ $retry_count -lt $max_retries ]]; then
                echo "⏳ Application not ready yet, retrying in 30 seconds... ($retry_count/$max_retries)"
                sleep 30
            fi
        fi
    done
    
    echo "⚠️  Application not yet responding after $((max_retries * 30 + 60)) seconds"
    echo "   This is normal for initial deployment. The application may take a few more minutes."
    echo "   Check the CloudWatch logs or SSH to the instance for startup progress."
}

# Cleanup on error
cleanup() {
    if [[ $? -ne 0 ]]; then
        echo ""
        echo "❌ Autonomous deployment failed. You may want to check the CloudFormation console:"
        echo "   https://console.aws.amazon.com/cloudformation/home?region=$AWS_REGION"
        echo ""
        echo "To clean up any created resources:"
        if [[ -n "$STACK_NAME" ]]; then
            echo "   aws cloudformation delete-stack --stack-name $STACK_NAME --region $AWS_REGION"
        fi
        if [[ -n "$S3_BUCKET_NAME" ]]; then
            echo "   aws s3 rb s3://$S3_BUCKET_NAME --force"
        fi
    fi
}

# Main execution
main() {
    trap cleanup EXIT
    
    echo "🤖 Starting fully autonomous deployment..."
    echo "   This will automatically:"
    echo "   ✅ Package your application"
    echo "   ✅ Create S3 bucket and upload"  
    echo "   ✅ Deploy complete AWS infrastructure"
    echo "   ✅ Install and start your application"
    echo "   ✅ Provide working application URL"
    echo ""
    
    read -p "🚀 Ready for autonomous deployment? This will create AWS resources. (y/n): " confirm
    if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
        echo "Deployment cancelled."
        exit 0
    fi
    
    check_prerequisites
    generate_deployment_config
    create_application_package
    upload_to_s3
    get_vpc_configuration
    get_instance_type
    get_key_pair
    deploy_stack
    get_outputs
    test_deployment
    
    echo ""
    echo "🎯 Autonomous Deployment Complete!"
    echo "================================"
    echo "Your EC2 Capacity Block Scanner is now running autonomously on AWS!"
    echo ""
    echo "Next Steps:"
    echo "1. Visit: $APPLICATION_URL"
    echo "2. Test the application functionality"
    echo "3. Monitor via CloudWatch logs"
    echo "4. SSH access: $SSH_COMMAND"
    echo ""
    echo "All resources created automatically. See deployment-info-autonomous.txt for details."
}

# Run main function
main "$@"
