"""
Core capacity checking algorithms and AWS API interactions
"""
import datetime as dt
from typing import List, Dict, Any, Tuple
import concurrent.futures
import time

from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from utils.aws_helpers import require_boto3, list_capacity_block_offerings, region_to_geo
from utils.formatters import fee_to_float, format_grid_cell
from config.constants import API_RETRY_ATTEMPTS


@retry(
    stop=stop_after_attempt(API_RETRY_ATTEMPTS),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type(Exception),
    reraise=True
)
def check_one_with_retry(region: str, instance_type: str, start_dt: dt.datetime, end_dt: dt.datetime,
                        duration_hours: int, count: int) -> Tuple[bool, Dict[str, Any]]:
    """Check capacity for a single region with retry and backoff."""
    boto3, ClientError = require_boto3()
    session = boto3.Session(region_name=region)
    ec2 = session.client("ec2", region_name=region)
    
    try:
        offers = list_capacity_block_offerings(ec2, instance_type, start_dt, end_dt, duration_hours, count)
    except ClientError as e:
        error_code = e.response.get('Error', {}).get('Code', '')
        if error_code in ['Throttling', 'RequestLimitExceeded', 'TooManyRequestsException']:
            # Re-raise throttling errors to trigger retry
            raise e
        return False, {"error": str(e)}
    except Exception as e:
        # For other exceptions, also retry
        raise e
    
    if not offers:
        return False, {}
    offers_sorted = sorted(offers, key=lambda o: fee_to_float(o.get("UpfrontFee")))
    return True, offers_sorted[0]


def check_one(region: str, instance_type: str, start_dt: dt.datetime, end_dt: dt.datetime,
              duration_hours: int, count: int) -> Tuple[bool, Dict[str, Any]]:
    """Check capacity for a single region - fallback to non-retry version for compatibility."""
    try:
        return check_one_with_retry(region, instance_type, start_dt, end_dt, duration_hours, count)
    except Exception as e:
        return False, {"error": str(e)}


class ParallelCapacityChecker:
    """Streamlit-compatible parallel capacity checker."""
    
    def __init__(self, max_workers: int = 10):
        self.max_workers = max_workers
        
    def check_regions_parallel(self, regions: List[str], instance_type: str, start_dt: dt.datetime, 
                              end_dt: dt.datetime, duration_hours: int, count: int) -> List[Dict[str, Any]]:
        """Check capacity across multiple regions in parallel - Streamlit compatible."""
        
        def process_region(region: str) -> Dict[str, Any]:
            try:
                ok, data = check_one_with_retry(region, instance_type, start_dt, end_dt, duration_hours, count)
                
                if ok:
                    return {
                        "Geography": region_to_geo(region), "Region": region, "Capacity": "Yes",
                        "AZ": data.get("AvailabilityZone"),
                        "Start": str(data.get("StartDate")), "End": str(data.get("EndDate")),
                        "DurationHours": data.get("CapacityBlockDurationHours"),
                        "Count": data.get("InstanceCount"),
                        "Price": data.get("UpfrontFee"), "Currency": data.get("CurrencyCode"),
                    }
                else:
                    result = {
                        "Geography": region_to_geo(region), "Region": region, "Capacity": "No",
                        "AZ": "", "Start": "", "End": "", "DurationHours": "", "Count": "",
                        "Price": "", "Currency": "",
                    }
                    if "error" in data:
                        result["Error"] = data["error"]
                    return result
                    
            except Exception as e:
                return {
                    "Geography": region_to_geo(region), "Region": region, "Capacity": "No",
                    "AZ": "", "Start": "", "End": "", "DurationHours": "", "Count": "",
                    "Price": "", "Currency": "", "Error": str(e)
                }
        
        # Submit all tasks and collect futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all tasks
            future_to_region = {executor.submit(process_region, region): region for region in regions}
            
            # Collect results as they complete
            results = []
            for future in concurrent.futures.as_completed(future_to_region):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    region = future_to_region[future]
                    results.append({
                        "Geography": region_to_geo(region), "Region": region, "Capacity": "No",
                        "AZ": "", "Start": "", "End": "", "DurationHours": "", "Count": "",
                        "Price": "", "Currency": "", "Error": str(e)
                    })
        
        return results
        
    def check_regions_with_progress(self, regions: List[str], instance_type: str, start_dt: dt.datetime, 
                                   end_dt: dt.datetime, duration_hours: int, count: int,
                                   progress_placeholder, status_container) -> List[Dict[str, Any]]:
        """Check regions with real-time progress updates."""
        
        def process_region(region: str) -> Tuple[str, Dict[str, Any]]:
            try:
                ok, data = check_one_with_retry(region, instance_type, start_dt, end_dt, duration_hours, count)
                
                if ok:
                    result = {
                        "Geography": region_to_geo(region), "Region": region, "Capacity": "Yes",
                        "AZ": data.get("AvailabilityZone"),
                        "Start": str(data.get("StartDate")), "End": str(data.get("EndDate")),
                        "DurationHours": data.get("CapacityBlockDurationHours"),
                        "Count": data.get("InstanceCount"),
                        "Price": data.get("UpfrontFee"), "Currency": data.get("CurrencyCode"),
                    }
                else:
                    result = {
                        "Geography": region_to_geo(region), "Region": region, "Capacity": "No",
                        "AZ": "", "Start": "", "End": "", "DurationHours": "", "Count": "",
                        "Price": "", "Currency": "",
                    }
                    if "error" in data:
                        result["Error"] = data["error"]
                
                return region, result
                    
            except Exception as e:
                return region, {
                    "Geography": region_to_geo(region), "Region": region, "Capacity": "No",
                    "AZ": "", "Start": "", "End": "", "DurationHours": "", "Count": "",
                    "Price": "", "Currency": "", "Error": str(e)
                }
        
        results = []
        completed_regions = []
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all tasks
            future_to_region = {executor.submit(process_region, region): region for region in regions}
            
            # Process results as they complete
            for future in concurrent.futures.as_completed(future_to_region):
                try:
                    region, result = future.result()
                    results.append(result)
                    completed_regions.append(region)
                    
                    # Update progress from main thread
                    progress = len(completed_regions) / len(regions)
                    progress_placeholder.progress(
                        progress,
                        text=f"Progress: {len(completed_regions)}/{len(regions)} regions ({progress*100:.1f}%) - Last: {region}"
                    )
                    
                    # Update status
                    status = "✅ Available" if result.get("Capacity") == "Yes" else "❌ No capacity"
                    with status_container:
                        import streamlit as st
                        st.text(f"• {region}: {status}")
                    
                except Exception as e:
                    region = future_to_region[future]
                    results.append({
                        "Geography": region_to_geo(region), "Region": region, "Capacity": "No",
                        "AZ": "", "Start": "", "End": "", "DurationHours": "", "Count": "",
                        "Price": "", "Currency": "", "Error": str(e)
                    })
                    completed_regions.append(region)
                    
                    progress = len(completed_regions) / len(regions)
                    progress_placeholder.progress(
                        progress,
                        text=f"Progress: {len(completed_regions)}/{len(regions)} regions ({progress*100:.1f}%) - Last: {region}"
                    )
        
        return results

    def check_grid_parallel(self, grid_tasks: List[Dict[str, Any]], instance_type: str, region: str, count: int) -> List[Dict[str, Any]]:
        """Check capacity for grid cells in parallel - Streamlit compatible."""
        
        def process_cell(task: Dict[str, Any]) -> Dict[str, Any]:
            try:
                row, col = task["row"], task["col"]
                start_dt, end_dt = task["start_dt"], task["end_dt"]
                duration_hours = task["duration_hours"]
                duration_days = task["duration_days"]
                
                if duration_days <= 0:
                    return {"row": row, "col": col, "cell_value": format_grid_cell(False, "", duration_days)}
                else:
                    ok, data = check_one_with_retry(region, instance_type, start_dt, end_dt, duration_hours, count)
                    
                    if ok:
                        price = data.get("UpfrontFee", "")
                        cell_value = format_grid_cell(True, price, duration_days)
                    else:
                        cell_value = format_grid_cell(False, "", duration_days)
                    
                    return {"row": row, "col": col, "cell_value": cell_value, "has_capacity": ok}
                
            except Exception as e:
                return {"row": task["row"], "col": task["col"], "cell_value": "❌", "error": str(e)}
        
        # Submit all tasks and collect results
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_task = {executor.submit(process_cell, task): task for task in grid_tasks}
            
            results = []
            for future in concurrent.futures.as_completed(future_to_task):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    task = future_to_task[future]
                    results.append({"row": task["row"], "col": task["col"], "cell_value": "❌", "error": str(e)})
        
        return results
