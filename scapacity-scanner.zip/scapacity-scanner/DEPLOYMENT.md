# EC2 Capacity Block Scanner

A Streamlit web application for scanning AWS EC2 Capacity Block availability across multiple regions. The application provides two main scanning modes: Multi-Region Scanner and Grid View Scanner.

## Features

- **Multi-Region Scanner**: Check capacity across all AWS regions simultaneously
- **Grid View Scanner**: Visual 7x7 date matrix for exploring date combinations  


## Project Structure

```
capacity_block/
├── main.py                                    # Main application entry point
├── requirements.txt                           # Python dependencies
├── config/                                    # Configuration modules
├── core/                                      # Core application logic
├── ui/                                        # User interface components
├── utils/                                     # Utility functions
├── static/                                    # Static assets (CSS, etc.)
├── cloudformation-template-autonomous.yaml    # AWS infrastructure template
└── deploy-autonomous.sh                       # Autonomous deployment script
```

## Local Development Setup

### Prerequisites
- Python 3.8 or higher
- AWS credentials configured (AWS CLI, environment variables, or IAM roles)

### Installation Steps

```bash
# Clone or navigate to project directory
cd capacity_block

# Activate virtual environment (if using the provided myenv)
source myenv/bin/activate

# Install dependencies (if needed)
pip install -r requirements.txt

# Run the application
streamlit run main.py
```

The application will be available at:
- **Local URL**: http://localhost:8501
- **Network URL**: http://[your-ip]:8501

### AWS Configuration

Configure your AWS credentials using one of these methods:

**Option A: AWS CLI**
```bash
aws configure
```

**Option B: Environment Variables**
```bash
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_DEFAULT_REGION=us-east-1
```

**Option C: IAM Role (recommended for EC2)**
- Attach an IAM role with EC2 describe permissions to your EC2 instance

### Local Testing

```bash
# Test AWS connectivity
aws sts get-caller-identity

# Test specific EC2 capacity blocks API
aws ec2 describe-capacity-block-offerings \
  --instance-type m5.large \
  --instance-count 1 \
  --start-date-range "2024-01-01T00:00:00.000Z" \
  --end-date-range "2024-01-31T23:59:59.999Z" \
  --capacity-duration-hours 24 \
  --region us-east-1

# Run the application and test locally
streamlit run main.py
```

## AWS Deployment

### Overview

The autonomous deployment creates a complete AWS infrastructure with:
- **EC2 Instance** running the Streamlit application
- **Elastic IP** for static public access
- **Security Group** with proper access controls
- **IAM Role** with minimal EC2 permissions
- **CloudWatch** logging and monitoring
- **S3 Bucket** for application deployment package

### Prerequisites
1. **AWS CLI** installed and configured
2. **EC2 Key Pair** created in your target region
3. **Proper IAM permissions** for CloudFormation, EC2, IAM, and S3

### Autonomous Deployment Process

The deployment script automates the entire process:

1. **Configuration Generation**: Automatically generates unique deployment identifiers
2. **Application Packaging**: Packages all necessary files, excluding development artifacts
3. **S3 Upload**: Creates S3 bucket and uploads application package
4. **Infrastructure Creation**: Deploys complete CloudFormation infrastructure
5. **Application Installation**: Downloads and installs application on EC2 automatically
6. **Service Configuration**: Configures and starts the application service
7. **Health Monitoring**: Sets up health checks and monitoring

### Quick Deployment

```bash
# Make deployment script executable
chmod +x deploy-autonomous.sh

# Run autonomous deployment
./deploy-autonomous.sh
```

The script will automatically:
- Check all prerequisites
- Package your application
- Create S3 bucket and upload application
- Deploy complete CloudFormation infrastructure
- Test the deployment
- Provide access URLs and monitoring information

### Manual CloudFormation Deployment

If you prefer manual deployment:

```bash
# Deploy the stack
aws cloudformation deploy \
  --template-file cloudformation-template-autonomous.yaml \
  --stack-name capacity-scanner-autonomous \
  --parameter-overrides \
    InstanceType=t3.medium \
    KeyPairName=your-key-pair-name \
    ProjectName=capacity-block-scanner \
    S3BucketName=your-unique-bucket-name \
    S3ApplicationKey=applications/your-app.zip \
  --capabilities CAPABILITY_NAMED_IAM \
  --region us-west-2
```

## Testing and Troubleshooting

### Step 1: Get Deployment Information

```bash
# Check your deployment info file (created by deploy-autonomous.sh)
cat deployment-info-autonomous.txt

# Or check CloudFormation outputs directly
aws cloudformation describe-stacks \
  --stack-name capacity-scanner-autonomous \
  --region [your-region] \
  --query 'Stacks[0].Outputs'
```

### Step 2: Basic Connectivity Tests

```bash
# Test HTTP connectivity (from your local machine)
curl -I http://[elastic-ip]:8501

# Test port connectivity
telnet [elastic-ip] 8501

# Or use nc (netcat) if available
nc -zv [elastic-ip] 8501
```

### Step 3: SSH to Instance for Diagnosis

```bash
# Connect to your EC2 instance
ssh -i [your-key].pem ec2-user@[elastic-ip]

# Check basic system status
whoami
df -h
free -h
uptime
```

### Step 4: Application Status Checks

```bash
# Check if application service is running
sudo systemctl status capacity-scanner-autonomous.service

# View recent service logs
sudo journalctl -u capacity-scanner-autonomous.service --no-pager -n 50

# Follow live logs
sudo journalctl -u capacity-scanner-autonomous.service -f

# Check if Streamlit process is running
ps aux | grep streamlit

# Verify application is listening on port 8501
sudo netstat -tlnp | grep 8501
```

### Step 5: Application Health and Files Check

```bash
# Verify application directory and files
ls -la /opt/capacity-scanner/
ls -la /opt/capacity-scanner/main.py
cat /opt/capacity-scanner/requirements.txt

# Check virtual environment
source /opt/capacity-scanner/venv/bin/activate
python --version
streamlit --version
pip list
deactivate

# Test local connectivity within instance
curl -I http://localhost:8501

# Run health check (if available)
sudo /opt/capacity-scanner/health-check.sh 2>/dev/null || echo "Health check script not found"
```

### Step 6: AWS Integration Testing

```bash
# Test AWS credentials from the instance
aws sts get-caller-identity

# Test EC2 capacity blocks API from instance
aws ec2 describe-capacity-block-offerings \
  --instance-type m5.large \
  --instance-count 1 \
  --start-date-range "2024-01-01T00:00:00.000Z" \
  --end-date-range "2024-01-31T23:59:59.999Z" \
  --capacity-duration-hours 24 \
  --region us-east-1 \
  --max-items 1

# Test specific regions that the app uses
for region in us-east-1 us-west-2 eu-west-1; do
  echo "Testing region: $region"
  aws ec2 describe-regions --region $region --region-names $region
done
```

### Step 7: CloudWatch Logs

```bash
# View CloudWatch logs (from your local machine)
aws logs describe-log-groups \
  --log-group-name-prefix "/aws/ec2/capacity-scanner" \
  --region [your-region]

# Get recent logs
aws logs filter-log-events \
  --log-group-name "/aws/ec2/capacity-scanner-autonomous" \
  --start-time $(date -d '1 hour ago' +%s)000 \
  --region [your-region]

# Or view from instance
sudo tail -f /var/log/capacity-scanner-app.log
sudo tail -f /var/log/capacity-scanner-error.log
sudo tail -f /var/log/cloud-init-output.log
```

### Common Issues and Solutions

| Issue | Diagnosis Command | Solution |
|-------|------------------|----------|
| Service not running | `sudo systemctl status capacity-scanner-autonomous.service` | `sudo systemctl restart capacity-scanner-autonomous.service` |
| Port not accessible | `sudo netstat -tlnp \| grep 8501` | Check security group, restart service |
| App files missing | `ls -la /opt/capacity-scanner/` | Check S3 download, re-run deployment |
| AWS API errors | `aws sts get-caller-identity` | Check IAM role permissions |
| Dependencies failed | `pip list` in venv | Check requirements.txt, reinstall |

### Expected Healthy Status

If everything is working correctly:
- `capacity-scanner-autonomous.service` should be **active (running)**
- Streamlit process visible in `ps aux | grep streamlit`
- Port 8501 listening: `sudo netstat -tlnp | grep 8501`
- Local response: `curl -I http://localhost:8501` returns HTTP 200
- External access: `curl -I http://[elastic-ip]:8501` returns HTTP 200
- AWS API working: `aws sts get-caller-identity` returns account info

## Configuration and Customization

### Environment Variables

```bash
# SSH to instance and edit service configuration
ssh -i [your-key].pem ec2-user@[elastic-ip]
sudo nano /etc/systemd/system/capacity-scanner-autonomous.service

# Add environment variables in [Service] section
Environment=AWS_DEFAULT_REGION=us-west-2
Environment=APP_DEBUG=false
Environment=STREAMLIT_SERVER_HEADLESS=true

# Reload and restart
sudo systemctl daemon-reload
sudo systemctl restart capacity-scanner-autonomous.service
```

### Application Settings

```bash
# Modify Streamlit configuration
sudo nano /etc/systemd/system/capacity-scanner-autonomous.service

# Edit ExecStart line to customize settings
ExecStart=/opt/capacity-scanner/venv/bin/streamlit run main.py \
  --server.port=8501 \
  --server.address=0.0.0.0 \
  --server.headless=true \
  --browser.gatherUsageStats=false \
  --theme.base=light
```



*Costs vary by region and usage patterns. Free tier eligible for t2.micro.*

## Security Considerations

### Network Security
- **Security Group**: SSH (22) and HTTP (8501) open to internet
- **Recommendation**: Restrict SSH to your IP for better security
- **Application**: Running on public port 8501 for web access

### IAM Security  
- **Minimal Permissions**: Only EC2 describe operations for capacity blocks
- **No Hardcoded Credentials**: Uses IAM instance profile
- **CloudWatch Access**: For logging and monitoring

### Best Practices
```bash
# Restrict SSH to your IP (recommended)
aws ec2 authorize-security-group-ingress \
  --group-id [security-group-id] \
  --protocol tcp \
  --port 22 \
  --cidr [your-ip]/32

aws ec2 revoke-security-group-ingress \
  --group-id [security-group-id] \
  --protocol tcp \
  --port 22 \
  --cidr 0.0.0.0/0
```

## Cleanup and Removal

### Complete Cleanup

```bash
# Get your deployment information first
cat deployment-info-autonomous.txt

# Delete CloudFormation stack (removes EC2, Security Group, IAM Role, etc.)
aws cloudformation delete-stack \
  --stack-name [your-stack-name] \
  --region [your-region]

# Delete S3 bucket (if you want to remove it)
aws s3 rb s3://[your-bucket-name] --force --region [your-region]

# Verify cleanup
aws cloudformation describe-stacks \
  --stack-name [your-stack-name] \
  --region [your-region]
```


## Support and Troubleshooting

### Quick Diagnostic Commands

```bash
# Full health check (run on EC2 instance)
echo "=== System Status ==="
uptime
df -h
free -h

echo "=== Service Status ==="
sudo systemctl status capacity-scanner-autonomous.service

echo "=== Network Status ==="
sudo netstat -tlnp | grep 8501

echo "=== Process Status ==="
ps aux | grep streamlit

echo "=== AWS Connectivity ==="
aws sts get-caller-identity

echo "=== Application Response ==="
curl -I http://localhost:8501
```

### Common Issues

1. **Application not loading**: 
   - Check security group allows port 8501
   - Verify service is running: `sudo systemctl status capacity-scanner-autonomous.service`

2. **AWS API errors**: 
   - Verify IAM role permissions
   - Test: `aws sts get-caller-identity`

3. **Service won't start**:
   - Check logs: `sudo journalctl -u capacity-scanner-autonomous.service -n 50`
   - Verify files exist: `ls -la /opt/capacity-scanner/`

4. **Deployment failures**:
   - Check CloudFormation events in AWS Console
   - Verify prerequisites (AWS CLI, permissions, key pair)

### Getting Help

For issues:
1. Run the diagnostic commands above
2. Check service logs: `sudo journalctl -u capacity-scanner-autonomous.service -f`
3. Verify all files deployed correctly: `ls -la /opt/capacity-scanner/`
4. Test AWS connectivity from the instance

## License

This project is provided as-is for educational and operational use. Modify as needed for your specific requirements.

**Deployment**: Run `./deploy-autonomous.sh` for one-command deployment to AWS.
