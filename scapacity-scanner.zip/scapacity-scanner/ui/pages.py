"""
Page-specific logic for multi-region and grid view scanners
"""
import datetime as dt
import time
import pandas as pd
import streamlit as st
from datetime import timezone

from core.capacity_checker import ParallelCapacityChecker
from utils.aws_helpers import get_enabled_regions, region_to_geo
from utils.date_helpers import create_datetime_utc, calculate_end_datetime, duration_hours_from_days
from utils.formatters import sorted_view, style_grid_dataframe
from ui.components import (
    create_grid_matrix, create_grid_navigation, create_grid_bottom_navigation
)


def run_multi_region_scan(controls: dict):
    """Execute multi-region capacity scan"""
    # Extract parameters
    instance_type = controls["instance_type"]
    primary_region = controls["primary_region"]
    quantity = controls["quantity"]
    earliest_date = controls["earliest_date"]
    duration_days = controls["duration_days"]
    concurrency = controls["concurrency"]
    
    # Calculate datetime range
    start_dt = create_datetime_utc(earliest_date)
    dur_hrs = duration_hours_from_days(int(duration_days))
    end_dt = calculate_end_datetime(start_dt, int(duration_days))
    primary_geo = region_to_geo(primary_region)

    # Get regions list
    regions = get_enabled_regions()
    if primary_region in regions:
        regions = [primary_region] + [r for r in regions if r != primary_region]

    # Create containers
    results_container = st.container()
    st.divider()
    logs_container = st.container()

    # Initial table
    with results_container:
        st.subheader("Capacity Block Availability by Region")
        table_placeholder = st.empty()
        init_rows = [{
            "Geography": region_to_geo(r),
            "Region": r,
            "Capacity": "",
            "AZ": "", "Start": "", "End": "", "DurationHours": "", "Count": "", "Price": "", "Currency": "",
        } for r in regions]
        table_placeholder.dataframe(sorted_view(pd.DataFrame(init_rows), primary_geo), use_container_width=True)

    with logs_container:
        st.subheader("Scan log")
        st.caption(f"Earliest start = {earliest_date.isoformat()} | Duration = {int(duration_days)} days ({dur_hrs} h). "
                   f"End = last day 23:59:59 UTC. Parallel processing with {concurrency} workers.")
        
        # Progress tracking
        progress_placeholder = st.empty()
        status_container = st.empty()
        
        # Show initial progress
        progress_placeholder.info(f"Starting parallel scan of {len(regions)} regions with {concurrency} workers...")
        
        # Create parallel checker and run
        start_time = time.time()
        checker = ParallelCapacityChecker(max_workers=concurrency)
        
        try:
            # Use Streamlit-compatible progress method
            with st.spinner("Scanning regions in parallel..."):
                final_results = checker.check_regions_parallel(
                    regions=regions,
                    instance_type=instance_type,
                    start_dt=start_dt,
                    end_dt=end_dt,
                    duration_hours=dur_hrs,
                    count=quantity
                )
            
            # Update final table with all results
            table_placeholder.dataframe(sorted_view(pd.DataFrame(final_results), primary_geo), use_container_width=True)
            
            # Final summary
            elapsed = time.time() - start_time
            available_count = sum(1 for r in final_results if r.get("Capacity") == "Yes")
            
            # Build summary logs
            summary_logs = []
            summary_logs.append(f"Scan completed in {elapsed:.1f}s")
            summary_logs.append(f"Found capacity in {available_count}/{len(regions)} regions")
            summary_logs.append(f"{len(regions)/elapsed:.1f} regions/second average")
            summary_logs.append("=" * 50)
            summary_logs.append("Results by region:")
            
            for result in final_results:
                region = result.get("Region", "Unknown")
                capacity = result.get("Capacity", "Unknown")
                if capacity == "Yes":
                    price = result.get("Price", "N/A")
                    summary_logs.append(f"✅ {region}: Available - ${price}")
                else:
                    error = result.get("Error", "")
                    if error:
                        summary_logs.append(f"❌ {region}: No capacity ({error})")
                    else:
                        summary_logs.append(f"❌ {region}: No capacity")
            
            # Display final status and logs
            if available_count > 0:
                progress_placeholder.success(f"Scan completed! Found capacity in {available_count} regions ({elapsed:.1f}s)")
            else:
                progress_placeholder.warning(f"Scan completed - No capacity found in any region ({elapsed:.1f}s)")
                
            # Show detailed results
            with status_container:
                st.text_area("Scan Results", value="\n".join(summary_logs), height=300, label_visibility="collapsed")
                
        except Exception as e:
            progress_placeholder.error(f"Scan failed: {str(e)}")
            with status_container:
                st.error(f"Error during parallel scan: {str(e)}")


def run_grid_scan(controls: dict):
    """Execute grid view capacity scan"""
    # Extract parameters
    instance_type = controls["instance_type"]
    region = controls["region"]
    quantity = controls["quantity"]
    base_date = controls["base_date"]
    concurrency = controls["concurrency"]
    
    # Initialize grid for parallel scanning
    grid_df = create_grid_matrix(base_date, st.session_state.start_offset, st.session_state.end_offset)
    
    # Show initial empty grid
    grid_container = st.container()
    logs_container = st.container()
    
    with grid_container:
        st.subheader(f"7x7 Capacity Grid - {region}")
        
        # Show current date ranges
        start_range_start = base_date + dt.timedelta(days=st.session_state.start_offset)
        start_range_end = base_date + dt.timedelta(days=st.session_state.start_offset + 6)
        end_range_start = base_date + dt.timedelta(days=st.session_state.end_offset)
        end_range_end = base_date + dt.timedelta(days=st.session_state.end_offset + 6)
        
        st.caption(f"Start Dates: {start_range_start.strftime('%m-%d')} to {start_range_end.strftime('%m-%d')} | "
                  f"End Dates: {end_range_start.strftime('%m-%d')} to {end_range_end.strftime('%m-%d')}")
        
        # Progress bar placeholder - positioned at top of table
        progress_placeholder = st.empty()
        
        # Grid navigation
        create_grid_navigation(base_date)
        
        # Grid display
        grid_placeholder = st.empty()
        grid_placeholder.dataframe(style_grid_dataframe(grid_df), use_container_width=True)
        
        # Bottom navigation
        create_grid_bottom_navigation()
    
    # Build list of grid tasks for parallel processing
    grid_tasks = []
    for row in range(7):
        for col in range(7):
            start_date = base_date + dt.timedelta(days=row + st.session_state.start_offset)
            end_date = base_date + dt.timedelta(days=col + st.session_state.end_offset)
            duration_days = (end_date - start_date).days
            
            if duration_days > 0:  # Only process valid combinations
                start_dt = create_datetime_utc(start_date)
                end_dt = create_datetime_utc(end_date, 23, 59, 59)
                dur_hrs = duration_days * 24
                
                grid_tasks.append({
                    "row": row, "col": col,
                    "start_date": start_date, "end_date": end_date,
                    "start_dt": start_dt, "end_dt": end_dt,
                    "duration_hours": dur_hrs, "duration_days": duration_days
                })
            else:
                # Mark invalid combinations immediately
                from utils.formatters import format_grid_cell
                grid_df.iloc[row, col] = format_grid_cell(False, "", duration_days)
    
    total_cells = len(grid_tasks)
    
    with logs_container:
        st.subheader("Grid Scan Progress")
        st.caption(f"Parallel processing with {concurrency} workers - {total_cells} valid date combinations")
        
        # Show initial progress
        progress_placeholder.info(f"Starting parallel grid scan for {region} - {total_cells} combinations")
        
        # Create parallel checker and run
        start_time = time.time()
        checker = ParallelCapacityChecker(max_workers=concurrency)
        
        try:
            if total_cells > 0:
                # Use Streamlit-compatible progress method
                with st.spinner(f"Scanning {total_cells} grid combinations in parallel..."):
                    final_results = checker.check_grid_parallel(
                        grid_tasks=grid_tasks,
                        instance_type=instance_type,
                        region=region,
                        count=quantity
                    )
                
                # Update grid with all results from main thread
                for result in final_results:
                    row, col = result["row"], result["col"]
                    cell_value = result["cell_value"]
                    grid_df.iloc[row, col] = cell_value
                
                # Show updated grid
                grid_placeholder.dataframe(style_grid_dataframe(grid_df), use_container_width=True)
                
                # Final summary
                elapsed = time.time() - start_time
                available_count = sum(1 for r in final_results if r.get("has_capacity", False))
                
                # Build summary logs
                summary_logs = []
                summary_logs.append(f"Grid scan completed in {elapsed:.1f}s")
                summary_logs.append(f"Found capacity in {available_count}/{total_cells} combinations")
                summary_logs.append(f"{total_cells/elapsed:.1f} cells/second average")
                summary_logs.append("=" * 50)
                summary_logs.append("Results by date combination:")
                
                for result in final_results:
                    row, col = result["row"], result["col"]
                    start_date = base_date + dt.timedelta(days=row + st.session_state.start_offset)
                    end_date = base_date + dt.timedelta(days=col + st.session_state.end_offset)
                    duration_days = (end_date - start_date).days
                    
                    if result.get("has_capacity", False):
                        summary_logs.append(f"✅ {start_date.strftime('%m-%d')} → {end_date.strftime('%m-%d')} ({duration_days}d): Available")
                    else:
                        error = result.get("error", "")
                        if error:
                            summary_logs.append(f"❌ {start_date.strftime('%m-%d')} → {end_date.strftime('%m-%d')} ({duration_days}d): No capacity ({error})")
                        else:
                            summary_logs.append(f"❌ {start_date.strftime('%m-%d')} → {end_date.strftime('%m-%d')} ({duration_days}d): No capacity")
                
                # Display final status and logs  
                if available_count > 0:
                    progress_placeholder.success(f"Grid scan completed! Found capacity in {available_count} cells ({elapsed:.1f}s)")
                else:
                    progress_placeholder.warning(f"Grid scan completed - No capacity found in any cell ({elapsed:.1f}s)")
                    
                # Show detailed results
                st.text_area("Grid Scan Results", value="\n".join(summary_logs), height=400, label_visibility="collapsed")
                    
            else:
                progress_placeholder.warning("No valid date combinations in current grid view - adjust date ranges")
                
        except Exception as e:
            progress_placeholder.error(f"Grid scan failed: {str(e)}")
            st.error(f"Error during parallel grid scan: {str(e)}")


def display_grid_view(controls: dict):
    """Display grid view without scanning"""
    base_date = controls["base_date"]
    region = controls["region"]
    
    grid_container = st.container()
    
    with grid_container:
        st.subheader(f"7x7 Capacity Grid - {region}")
        
        # Progress bar placeholder - positioned at top of table
        progress_placeholder = st.empty()
        
        # Grid navigation
        create_grid_navigation(base_date)
        
        # Show empty grid with current offsets
        empty_grid = create_grid_matrix(base_date, st.session_state.start_offset, st.session_state.end_offset)
        st.dataframe(style_grid_dataframe(empty_grid), use_container_width=True)
        st.info("Click **Scan Grid** to check capacity availability for the displayed date ranges.")
        
        # Bottom navigation
        create_grid_bottom_navigation()
