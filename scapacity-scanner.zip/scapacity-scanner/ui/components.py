"""
Reusable UI components and helper functions
"""
import datetime as dt
import pandas as pd
import streamlit as st
from typing import List, Optional

from config.constants import (
    VALID_DURATIONS, DEFAULT_INSTANCE_TYPE, DEFAULT_REGION, DEFAULT_QUANTITY, 
    DEFAULT_DURATION_DAYS, DEFAULT_CONCURRENCY, DEFAULT_GRID_CONCURRENCY,
    MAX_WORKERS_LIMIT, MAX_GRID_WORKERS_LIMIT, INSTANCE_COUNT_RANGE, GRID_SIZE
)
from utils.date_helpers import generate_date_range
from utils.formatters import format_grid_cell, style_grid_dataframe


def load_css(css_file: str = "static/styles.css"):
    """Load CSS from external file"""
    try:
        with open(css_file, "r") as f:
            css_content = f.read()
        st.markdown(f"<style>{css_content}</style>", unsafe_allow_html=True)
    except FileNotFoundError:
        st.warning(f"CSS file {css_file} not found. Using default styling.")


def setup_page_config():
    """Setup Streamlit page configuration"""
    st.set_page_config(page_title="EC2 Capacity Blocks Scanner", layout="wide")
    st.title("EC2 Capacity Blocks Scanner")


def create_sidebar_controls(page_type: str) -> dict:
    """Create sidebar controls based on page type"""
    controls = {}
    
    with st.sidebar:
        if page_type == "multi_region":
            st.header("Multi-Region Scan Parameters")
            controls["instance_type"] = st.text_input(
                "Instance Type", 
                value=st.session_state.get("scan_inst", DEFAULT_INSTANCE_TYPE), 
                key="scan_inst"
            )
            controls["primary_region"] = st.text_input(
                "Primary Region", 
                value=st.session_state.get("scan_region", DEFAULT_REGION), 
                key="scan_region"
            )
            controls["quantity"] = st.number_input(
                "Instance Count", 
                min_value=INSTANCE_COUNT_RANGE[0], 
                max_value=INSTANCE_COUNT_RANGE[1], 
                value=int(st.session_state.get("scan_qty", DEFAULT_QUANTITY)), 
                step=1, 
                key="scan_qty"
            )
            controls["earliest_date"] = st.date_input(
                "Earliest Start Date", 
                value=st.session_state.get("scan_start", dt.date.today()), 
                key="scan_start"
            )
            controls["duration_days"] = st.selectbox(
                "Duration (days)", 
                VALID_DURATIONS, 
                index=VALID_DURATIONS.index(int(st.session_state.get("scan_dur", DEFAULT_DURATION_DAYS))), 
                key="scan_dur"
            )
            
            st.divider()
            st.subheader("Performance Settings")
            controls["concurrency"] = st.number_input(
                "Max Concurrent Regions", 
                min_value=1, 
                max_value=MAX_WORKERS_LIMIT, 
                value=int(st.session_state.get("scan_concurrency", DEFAULT_CONCURRENCY)), 
                step=1, 
                key="scan_concurrency", 
                help="Number of regions to check simultaneously"
            )
            
            controls["run_scan"] = st.button("Scan All Regions", type="primary", key="scan_run_btn")
            
        elif page_type == "grid":
            st.header("Grid View Parameters")
            controls["instance_type"] = st.text_input(
                "Instance Type", 
                value=st.session_state.get("grid_inst", DEFAULT_INSTANCE_TYPE), 
                key="grid_inst"
            )
            controls["region"] = st.text_input(
                "Target Region", 
                value=st.session_state.get("grid_region", DEFAULT_REGION), 
                key="grid_region"
            )
            controls["quantity"] = st.number_input(
                "Instance Count", 
                min_value=INSTANCE_COUNT_RANGE[0], 
                max_value=INSTANCE_COUNT_RANGE[1], 
                value=int(st.session_state.get("grid_qty", DEFAULT_QUANTITY)), 
                step=1, 
                key="grid_qty"
            )
            controls["base_date"] = st.date_input(
                "Base Date", 
                value=st.session_state.get("grid_base", dt.date.today()), 
                key="grid_base"
            )
            st.caption("Grid shows 7 days starting from base date")
            
            st.divider()
            st.subheader("Performance Settings")
            controls["concurrency"] = st.number_input(
                "Max Concurrent Cells", 
                min_value=1, 
                max_value=MAX_GRID_WORKERS_LIMIT, 
                value=int(st.session_state.get("grid_concurrency", DEFAULT_GRID_CONCURRENCY)), 
                step=1, 
                key="grid_concurrency", 
                help="Number of grid cells to check simultaneously"
            )
            
            controls["run_scan"] = st.button("Scan Grid", type="primary", key="grid_scan_btn")
    
    return controls


def create_grid_matrix(base_date: dt.date, start_offset: int = 0, end_offset: int = 0, grid_size: int = GRID_SIZE) -> pd.DataFrame:
    """Create empty grid matrix for capacity visualization."""
    # Calculate start and end date ranges with offsets
    start_dates = generate_date_range(base_date, start_offset, grid_size)
    end_dates = generate_date_range(base_date, end_offset, grid_size)
    
    start_date_strs = [d.strftime("%m-%d") for d in start_dates]
    end_date_strs = [d.strftime("%m-%d") for d in end_dates]
    
    # Create DataFrame with end dates as columns, start dates as rows
    grid_data = {}
    for col_idx, end_date_str in enumerate(end_date_strs):
        grid_data[f"End: {end_date_str}"] = ["" for _ in range(grid_size)]
    
    grid_df = pd.DataFrame(grid_data)
    grid_df.index = [f"Start: {date_str}" for date_str in start_date_strs]
    return grid_df


def create_grid_navigation(base_date: dt.date):
    """Create grid navigation controls"""
    # Initialize offset values
    if "start_offset" not in st.session_state:
        st.session_state.start_offset = 0
    if "end_offset" not in st.session_state:
        st.session_state.end_offset = 0

    # Show current date ranges
    start_range_start = base_date + dt.timedelta(days=st.session_state.start_offset)
    start_range_end = base_date + dt.timedelta(days=st.session_state.start_offset + 6)
    end_range_start = base_date + dt.timedelta(days=st.session_state.end_offset)
    end_range_end = base_date + dt.timedelta(days=st.session_state.end_offset + 6)
    
    st.caption(f"Start Dates: {start_range_start.strftime('%m-%d')} to {start_range_end.strftime('%m-%d')} | "
              f"End Dates: {end_range_start.strftime('%m-%d')} to {end_range_end.strftime('%m-%d')}")
    
    # Perfect table-aligned navigation layout
    # Top navigation row - aligned with table width
    top_nav_row = st.columns([1, 10, 1])
    with top_nav_row[0]:
        # Top left corner - Start dates decrease (up) and End dates decrease (left)
        left_arrows = st.columns([1, 1])
        with left_arrows[0]:
            if st.button("▲", key="start_prev", help="Start dates -7d"):
                st.session_state.start_offset -= 7
        with left_arrows[1]:
            if st.button("◀", key="end_prev", help="End dates -7d"):
                st.session_state.end_offset -= 7
    with top_nav_row[2]:
        # Top right corner - End dates increase (right)
        if st.button("▶", key="end_next", help="End dates +7d"):
            st.session_state.end_offset += 7
    
    return top_nav_row


def create_grid_bottom_navigation():
    """Create bottom navigation for grid"""
    # Bottom navigation row - aligned with table width
    bottom_nav_row = st.columns([1, 10, 1])
    with bottom_nav_row[0]:
        # Bottom left corner - Start dates increase (down)
        if st.button("▼", key="start_next", help="Start dates +7d"):
            st.session_state.start_offset += 7
    
    return bottom_nav_row


def synchronize_page_parameters(current_page: str, previous_page: str):
    """Synchronize parameters when switching between pages"""
    if previous_page != current_page:
        # User switched views - synchronize all parameters
        if previous_page == "Multi-Region Scanner" and current_page == "Grid View Scanner":
            # Switching from Multi-Region to Grid View - sync all parameters
            if "scan_start" in st.session_state:
                st.session_state.grid_base = st.session_state.scan_start
            if "scan_inst" in st.session_state:
                st.session_state.grid_inst = st.session_state.scan_inst
            if "scan_qty" in st.session_state:
                st.session_state.grid_qty = st.session_state.scan_qty
            if "scan_region" in st.session_state:
                st.session_state.grid_region = st.session_state.scan_region
                
        elif previous_page == "Grid View Scanner" and current_page == "Multi-Region Scanner":
            # Switching from Grid View to Multi-Region - sync all parameters
            if "grid_base" in st.session_state:
                st.session_state.scan_start = st.session_state.grid_base
            if "grid_inst" in st.session_state:
                st.session_state.scan_inst = st.session_state.grid_inst
            if "grid_qty" in st.session_state:
                st.session_state.scan_qty = st.session_state.grid_qty
            if "grid_region" in st.session_state:
                st.session_state.scan_region = st.session_state.grid_region


def display_empty_results(page_type: str):
    """Display empty results placeholder with proper alignment"""
    if page_type == "multi_region":
        # Results section with consistent container structure
        st.subheader("Capacity Block Availability by Region")
        st.info("Set parameters in the sidebar and click **Scan All Regions** to run an exact-window lookup.")
        
        # Add divider for visual separation
        st.divider()
        
        # Logs section with consistent container structure
        st.subheader("Scan log")
        st.caption("Logs will appear here during the scan.")
        st.text_area("Scan log", value="", height=220, label_visibility="collapsed", key="multi_region_logs_empty")
    
    elif page_type == "grid":
        # Grid progress section with consistent container structure
        st.subheader("Grid Scan Progress")
        st.caption("Progress will appear here during scanning.")
        st.text_area("Scan Progress", value="", height=200, label_visibility="collapsed", key="grid_logs_empty")
