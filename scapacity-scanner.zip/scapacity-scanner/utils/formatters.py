"""
Data formatting and display utility functions
"""
import pandas as pd
from typing import Any


def fee_to_float(s) -> float:
    """Convert fee string to float, return infinity on error"""
    try:
        return float(s)
    except Exception:
        return float("inf")


def df_for_display(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure Arrow-friendly types for Streamlit; everything as string."""
    return df.fillna("").astype(str)


def style_capacity_rows(df: pd.DataFrame) -> "pd.io.formats.style.Styler":
    """Style DataFrame rows based on capacity availability"""
    def _row_style(row):
        return ["background-color: #e8f5e9" if (str(row.get("Capacity")) == "Yes") else "" for _ in row.index]
    
    df = df_for_display(df)
    styler = df.style.apply(_row_style, axis=1)
    
    # Hide index using the correct method for current Streamlit version
    try:
        styler = styler.hide(axis="index")
    except Exception:
        try:
            styler = styler.hide_index()
        except Exception:
            # For newer versions, use hide with axis parameter
            try:
                styler = styler.hide(axis=0)
            except Exception:
                pass  # If all methods fail, continue without hiding index
    return styler


def sorted_view(df: pd.DataFrame, primary_geo: str) -> "pd.io.formats.style.Styler":
    """Create sorted view of capacity data with primary geography first"""
    if df.empty:
        return style_capacity_rows(df)
    
    cols = ["Geography", "Region", "Capacity", "AZ", "Start", "End", "DurationHours", "Count", "Price", "Currency"]
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    df = df[cols]

    # Primary geography first
    df["GeoRank"] = df["Geography"].apply(lambda g: 0 if g == primary_geo else 1)

    # Capacity order Yes > No > blank
    cap_cat = pd.CategoricalDtype(categories=["Yes", "No", ""], ordered=True)
    try:
        df["Capacity"] = df["Capacity"].astype(cap_cat)
    except Exception:
        pass

    # Sort
    try:
        df["PriceNum"] = pd.to_numeric(df["Price"], errors="coerce")
        df = df.sort_values(by=["GeoRank", "Geography", "Capacity", "PriceNum", "Region"],
                            ascending=[True, True, True, True, True])
    finally:
        df = df.drop(columns=["PriceNum", "GeoRank"], errors="ignore")

    df = df_for_display(df)
    return style_capacity_rows(df)


def format_grid_cell(has_capacity: bool, price: str = "", duration_days: int = 0) -> str:
    """Format grid cell content based on capacity and duration"""
    if duration_days <= 0:
        return "N/A"
    elif has_capacity:
        return f"✅ ${price}" if price else "✅"
    else:
        return "❌"


def style_grid_dataframe(df: pd.DataFrame) -> "pd.io.formats.style.Styler":
    """Apply styling to grid dataframe"""
    def style_cell(val):
        if val == "N/A":
            return "background-color: #f0f0f0; color: #999999; text-align: center;"
        elif val.startswith("✅"):
            return "background-color: #e8f5e9; color: #2e7d32; text-align: center; font-weight: bold;"
        elif val.startswith("❌"):
            return "background-color: #ffebee; color: #c62828; text-align: center;"
        else:
            return "text-align: center;"
    
    styler = df.style.applymap(style_cell)
    
    # Hide index for grid display as well
    try:
        styler = styler.hide(axis="index")
    except Exception:
        try:
            styler = styler.hide_index()
        except Exception:
            try:
                styler = styler.hide(axis=0)
            except Exception:
                pass  # If all methods fail, continue without hiding index
    
    return styler
