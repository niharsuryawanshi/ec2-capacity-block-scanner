"""
Date manipulation and utility functions
"""
import datetime as dt
from datetime import timezone


def duration_hours_from_days(days: int) -> int:
    """Convert days to hours"""
    return int(days) * 24


def create_datetime_utc(date_obj: dt.date, hour: int = 0, minute: int = 0, second: int = 0) -> dt.datetime:
    """Create a UTC datetime from a date object"""
    return dt.datetime(
        date_obj.year, date_obj.month, date_obj.day, 
        hour, minute, second, tzinfo=timezone.utc
    )


def calculate_end_datetime(start_dt: dt.datetime, duration_days: int) -> dt.datetime:
    """Calculate end datetime for exact window (last day 23:59:59)"""
    return (start_dt + dt.timedelta(days=duration_days + 1)) - dt.timedelta(seconds=1)


def calculate_duration_days(start_date: dt.date, end_date: dt.date) -> int:
    """Calculate duration in days between two dates"""
    return (end_date - start_date).days


def format_date_range(start_date: dt.date, end_date: dt.date, offset: int = 0) -> str:
    """Format date range with optional offset"""
    adjusted_start = start_date + dt.timedelta(days=offset)
    adjusted_end = end_date + dt.timedelta(days=offset)
    return f"{adjusted_start.strftime('%m-%d')} to {adjusted_end.strftime('%m-%d')}"


def generate_date_range(base_date: dt.date, offset: int = 0, size: int = 7) -> list:
    """Generate a list of dates from base date with offset"""
    return [base_date + dt.timedelta(days=i + offset) for i in range(size)]
