"""
AWS-related utility functions
"""
from typing import List, Optional
import streamlit as st


def require_boto3():
    """Import and return boto3 and ClientError, with error handling"""
    try:
        import boto3
        from botocore.exceptions import ClientError
        return boto3, ClientError
    except Exception:
        st.error("boto3/botocore are required. Install deps with `pip install -r requirements.txt`.")
        raise


@st.cache_data(show_spinner=False, ttl=300)
def get_enabled_regions() -> List[str]:
    """Get list of enabled AWS regions"""
    boto3, _ = require_boto3()
    try:
        session = boto3.Session(region_name="us-east-1")
        ec2 = session.client("ec2", region_name="us-east-1")
        resp = ec2.describe_regions(AllRegions=False)
        names = [r.get("RegionName") for r in resp.get("Regions", [])
                 if r.get("OptInStatus") in (None, "opt-in-not-required", "opted-in")]
        if not names:
            names = [
                "us-east-1", "us-east-2", "us-west-1", "us-west-2",
                "eu-west-1", "eu-west-2", "eu-west-3", "eu-central-1", "eu-central-2",
                "eu-south-1", "eu-south-2", "eu-north-1",
                "ap-south-1", "ap-south-2", "ap-southeast-1", "ap-southeast-2", 
                "ap-southeast-3", "ap-southeast-4", "ap-northeast-1", "ap-northeast-2", 
                "ap-northeast-3", "ap-east-1"
            ]
        return sorted(names)
    except Exception:
        return [
            "us-east-1", "us-east-2", "us-west-1", "us-west-2",
            "eu-west-1", "eu-west-2", "eu-west-3", "eu-central-1", "eu-central-2",
            "eu-south-1", "eu-south-2", "eu-north-1",
            "ap-south-1", "ap-south-2", "ap-southeast-1", "ap-southeast-2", 
            "ap-southeast-3", "ap-southeast-4", "ap-northeast-1", "ap-northeast-2", 
            "ap-northeast-3", "ap-east-1"
        ]


def region_to_geo(region: str) -> str:
    """Convert AWS region name to geographic description"""
    r = (region or "").lower()
    if r.startswith("us-east-"):
        return "US East"
    if r.startswith("us-west-"):
        return "US West"
    if r.startswith("us-"):
        return "USA (Other)"
    if r.startswith("ca-"):
        return "Canada"
    if r.startswith("eu-"):
        return "Europe"
    if r.startswith("ap-"):
        return "Asia Pacific"
    if r.startswith(("me-", "il-")):
        return "Middle East"
    if r.startswith("af-"):
        return "Africa"
    if r.startswith("sa-"):
        return "South America"
    if r.startswith("cn-"):
        return "China"
    return "Other"


def list_capacity_block_offerings(ec2, instance_type: str, start_dt, end_dt, 
                                  duration_hours: int, count: int):
    """List capacity block offerings from AWS EC2 API"""
    resp = ec2.describe_capacity_block_offerings(
        InstanceType=instance_type,
        InstanceCount=count,
        StartDateRange=start_dt,
        EndDateRange=end_dt,
        CapacityDurationHours=duration_hours,
        MaxResults=100
    )
    return resp.get("CapacityBlockOfferings", [])
