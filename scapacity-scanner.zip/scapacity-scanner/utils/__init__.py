# Utility functions and helpers
